package ec.edu.espoch.derivexpon.modelo;

public class BaseNatural extends Exponciales{
    public String MostraResultado(){
        separarEcuacionEnTerminos();   
        return "(" + resolverEcuacion() + ")" + "(" + getVariable() + "ln" + getCoeficiente() + ")";     
    }
}