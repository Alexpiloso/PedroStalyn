package ec.edu.espoch.derivexpon;

import ec.edu.espoch.derivexpon.vista.Interfaz;

public class DerivExpon {

    public static void main(String[] args) {
        Interfaz vista = new Interfaz();
        vista.setVisible(true);
        vista.setLocationRelativeTo(null);
    }
}
