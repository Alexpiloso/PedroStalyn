package ec.edu.espoch.derivexpon.modelo;

public class BaseNeperiana extends Exponciales{
    public String MostraResultado(){
        separarEcuacionEnTerminos();   
        return "(" + resolverEcuacion() + ")" + "(" + getVariable() + ")";     
    }
}
