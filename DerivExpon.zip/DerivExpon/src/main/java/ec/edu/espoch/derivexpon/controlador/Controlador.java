package ec.edu.espoch.derivexpon.controlador;

import ec.edu.espoch.derivexpon.modelo.BaseNatural;
import ec.edu.espoch.derivexpon.modelo.BaseNeperiana;
import ec.edu.espoch.derivexpon.vista.Interfaz;

public class Controlador {
    private Interfaz vista;
    private BaseNatural basNat;
    private BaseNeperiana basNep;

    public Controlador(Interfaz vista) {
        this.vista = vista;
        this.basNat = new BaseNatural();
        this.basNep = new BaseNeperiana();
    }
    
    public void accionBoton(){
        String funcion = String.valueOf(this.vista.getEntrada());
        if(funcion.contains("e")){
            basNep.setVariable(funcion);
            this.vista.setResul(this.basNep.MostraResultado());
        }else{
            basNat.setVariable(funcion);
            this.vista.setResul(this.basNat.MostraResultado());
        }
    }
}
