package ec.edu.espoch.derivexponpr;

import ec.edu.espoch.derivexponpr.vista.Interfaz;

public class DerivExponPr {

    public static void main(String[] args) {
        Interfaz vista = new Interfaz();
        vista.setVisible(true);
        vista.setLocationRelativeTo(null);
    }
}
