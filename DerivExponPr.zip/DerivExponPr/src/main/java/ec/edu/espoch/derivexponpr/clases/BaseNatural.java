package ec.edu.espoch.derivexponpr.clases;

import reactor.core.publisher.Mono;

public class BaseNatural extends Exponenciales{
    public Mono<String> mostrarResultadoReactivo() {
        return resolverEcuacionReactiva().map(resultado ->
                "(" + resultado + ")" + "(" + getVariable() + "ln" + getCoeficiente() + ")");
    }
}