package ec.edu.espoch.derivexponpr.clases;

import reactor.core.publisher.Mono;

public class Exponenciales {
    private String variable;
    private String[] terminosEcuacion;
    private String resultadoEcuacion = "";
    private String coeficiente;

    public Exponenciales() {}

    public String[] separarEcuacionEnTerminos() {
        if (variable.contains("e")) {
            int indiceInicio = variable.indexOf('(');
            if (indiceInicio != -1) {
                int indiceFin = variable.indexOf(')', indiceInicio);

                if (indiceFin != -1) {
                    String valor = variable.substring(indiceInicio + 1, indiceFin);
                    terminosEcuacion = valor.split(" ");
                }
            }
        } else {
            int indiceCaret = variable.indexOf("^");

            if (indiceCaret != -1) {
                coeficiente = variable.substring(0, indiceCaret).trim();
                String valor = variable.substring(indiceCaret + 1).replaceAll("[()]", "").trim();
                terminosEcuacion = valor.split(" ");
            }
        }
        return terminosEcuacion;
    }

    public Mono<String> resolverEcuacionReactiva() {
        resultadoEcuacion = "";
        boolean primerTerminoAgregado = false;

        for (String termino : terminosEcuacion) {
            int coeficiente;
            int exponente;

            boolean contieneVariable;

            if (termino.contains("x")) {
                contieneVariable = true;

                String parteNumerica = termino.substring(0, termino.indexOf("x"));

                if (parteNumerica.isEmpty() || parteNumerica.equals("+")) {
                    coeficiente = 1;
                } else if (parteNumerica.equals("-")) {
                    coeficiente = -1;
                } else {
                    coeficiente = Integer.parseInt(parteNumerica);
                }

                if (termino.contains("^")) {
                    String parteExponente = termino.substring(termino.indexOf("^") + 1);
                    exponente = Integer.parseInt(parteExponente);
                } else {
                    exponente = 1;
                }
            } else {
                contieneVariable = false;
                coeficiente = Integer.parseInt(termino);
                exponente = 0;
            }

            String resultadoParcial = "";

            if (contieneVariable & exponente != 1 & exponente != 2) {
                double nuevoExponente = exponente - 1;

                double nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                String nuevoExponenteString = String.valueOf(nuevoExponente);

                resultadoParcial = nuevoCoeficienteString + "x^" + nuevoExponenteString;
            } else if (contieneVariable & exponente == 2) {

                double nuevoCoeficiente = coeficiente * exponente;

                String nuevoCoeficienteString = String.valueOf(nuevoCoeficiente);
                resultadoParcial = nuevoCoeficienteString + "x";
            } else if (contieneVariable & exponente == 1) {
                String nuevoCoeficienteString = String.valueOf(coeficiente);
                resultadoParcial = nuevoCoeficienteString;
            } else {
                resultadoParcial = "";
            }

            if (!primerTerminoAgregado) {
                resultadoEcuacion = resultadoEcuacion + resultadoParcial;
                primerTerminoAgregado = true;
            } else {
                if (coeficiente > 0) {
                    resultadoEcuacion = resultadoEcuacion + "  +" + resultadoParcial;
                } else {
                    resultadoEcuacion = resultadoEcuacion + "  " + resultadoParcial;
                }
            }    
        }
        return Mono.just(resultadoEcuacion);
    }
    // Getters y setters...
    public String getVariable() {
        return variable;
    }
    public void setVariable(String variable) {
        this.variable = variable;
    }
    public String getCoeficiente() {
        return coeficiente;
    }
    public void setCoeficiente(String coeficiente) {
        this.coeficiente = coeficiente;
    }
}