package ec.edu.espoch.derivexponpr.clases;

import reactor.core.publisher.Mono;

public class BaseNeperiana extends Exponenciales{
    public Mono<String> mostrarResultadoReactivo() {
        return resolverEcuacionReactiva().map(resultado ->
                "(" + resultado + ")" + "(" + getVariable() + ")");
    }
}
